package main

import (
	"encoding/xml"
	"fmt"
	//"io/ioutil"
	"bufio"
	"os"
	//"time"
)

type FilesNode struct {
	FileItems []FileItemNode `xml:"FileItem"`
}
type FileItemNode struct {
	Name  string `xml:"name,attr"`
	Mtime string `xml:"mtime,attr"`
	Ver   int    `xml:"ver,attr"`
}
type VerNode struct {
	Str string `xml:"str,attr"`
}
type Result struct {
	XMLName xml.Name  `xml:"xml"`
	Ver     VerNode   `xml:"ver"`
	Files   FilesNode `xml:"files"`
}

func (v *Result) getXmlByFile(path string) (fn *FileItemNode) {
	for i := 0; i < len(v.Files.FileItems); i++ {
		fileitem := &v.Files.FileItems[i]
		if fileitem.Name == path {
			fn = fileitem
			return
		}
	}
	fn = nil
	return
}
func (v *Result) appendFile(fn FileItemNode) {
	v.Files.FileItems = append(v.Files.FileItems, fn)
}

func parseXML() (v *Result) {
	//var v Result

	f, err := os.OpenFile("ver.xml", os.O_RDWR|os.O_CREATE, os.ModeAppend)
	if err != nil {
		panic(err)
	}
	defer f.Close()

	//xmlFile, err := ioutil.ReadFile("ver.xml")
	//if err != nil {
	//	fmt.Println("Error opening file: ", err)
	//	return
	//}

	fileinfo, _ := f.Stat()
	bs := make([]byte, fileinfo.Size())
	f.Read(bs)
	fmt.Println("byte len:", len(bs))
	err1 := xml.Unmarshal(bs, &v)
	if err1 != nil {
		fmt.Printf("error Unmarshal: %v(%d)", err, len(bs))
		return
	}
	fmt.Printf("xml:%s\n", v)
	return
}

func writeXML(v *Result) {

	f, err := os.OpenFile("ver.xml", os.O_RDWR|os.O_CREATE, os.ModeAppend)
	if err != nil {
		panic(err)
	}
	defer f.Close()

	fmt.Printf("xml:%s", v)

	output, err := xml.MarshalIndent(v, "  ", "    ")
	if err != nil {
		fmt.Printf("error: %v\n", err)
	}
	f.Truncate(0)
	f.Seek(0, 0)
	outputWriter := bufio.NewWriter(f)
	nn, err := outputWriter.Write([]byte(xml.Header))
	fmt.Println(nn)

	nn, err = outputWriter.Write(output)
	fmt.Println(nn)
	outputWriter.Flush()
}
