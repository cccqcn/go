package main

import (
	ftp4go "code.google.com/p/ftp4go"
	"fmt"
	"os"
	"strings"
)

var TMP_UPDATE_DIR string = "E:\\test\\ftp\\local\\"
var ftp_root_dir string = "/"
var LOG_FILE string = "E:\\test\\ftp\\log.txt"

func connect() (ftpClient *ftp4go.FTP) {

	ftpClient = ftp4go.NewFTP(0) // 1 for debugging

	//connect
	_, err := ftpClient.Connect("192.168.1.104", ftp4go.DefaultFtpPort, "")
	if err != nil {
		fmt.Println("The connection failed")
		os.Exit(1)
	} else {
		fmt.Println("The connection OK")
	}
	//defer ftpClient.Quit()

	_, err = ftpClient.Login("test", "test", "")
	if err != nil {
		fmt.Println("The login failed")
		os.Exit(1)
	}
	return
}

func uploadFiles(files []File) {
	log := ""
	log += now() + " BEGIN UPDATE TO FTP\n"
	ftp := connect()
	if ftp != nil {
		log += now() + " Connected to FTP Server Success\n"
		//fmt.Println(log)
		for _, f := range files {
			log += now() + " file:" + f.path + "\n"
			//from := f.path
			fmt.Println(f.path)
			path := f.path[len(TMP_UPDATE_DIR):]
			to := path
			start := strings.LastIndex(path, "\\")
			if start == -1 {
				path = ftp_root_dir
			} else {
				path = ftp_root_dir + path[:start]
				_, err := ftp.Mkd(path)
				if err != nil {
					fmt.Println("mkd err:", err)
				}
			}
			to = strings.Replace(to, "\\", "/", -1)
			fmt.Println(path, to)
			to = ftp_root_dir + to
			err := ftp.UploadFile(to, f.path, false, nil)
			result := "Success"
			if err != nil {
				result = "Failed"
			}
			log += now() + " Upload:" + f.path + " -> " + to + " " + result + "\n"
		}
		ftp.Quit()
		fmt.Println("ftp.Quit")
	} else {
		log += now() + " Connected to FTP Server False\n"
	}
	log += now() + " END UPDATE\n\n"

	f, _ := os.OpenFile(LOG_FILE, os.O_APPEND, 0666)
	f.WriteString(log)
	f.Close()
}
