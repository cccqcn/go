// FirstGo project doc.go

/*
FirstGo document
*/
package main
