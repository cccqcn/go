package main

import (
	//"fmt"
	"os"
)

type File struct {
	fi   os.FileInfo
	path string
}

func getList(path string) (fi []File) {
	dir, _ := os.Open(path)
	files, _ := dir.Readdir(0)
	fi = make([]File, 0, 5)
	for _, f := range files {
		if f.IsDir() {
			//fmt.Println("d:" + f.Name())
			fi2 := getList(path + "\\" + f.Name())
			fi = concat(fi, fi2)
		} else {
			//fmt.Println("f:" + f.Name())
			file := File{f, path + "\\" + f.Name()}
			fi = append(fi, file)
		}
	}
	return
}
func concat(old1, old2 []File) []File {
	newslice := make([]File, len(old1)+len(old2))
	copy(newslice, old1)
	copy(newslice[len(old1):], old2)
	return newslice
}
