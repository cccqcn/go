// FirstGo project main.go
package main

import (
	"bufio"
	"fmt"
	"os"
	"time"
)

func main() {
	fmt.Println("Hello World!")
	//ioutil.ReadFile("")
	v := parseXML()
	files := getList(TMP_UPDATE_DIR)
	uploads := make([]File, 0)
	upload := false
	for _, f := range files {
		upload = false
		fname := f.path
		ftime := f.fi.ModTime().Format("2006-01-02 15:04:05")
		fmt.Println(fname + " " + ftime)
		fn := v.getXmlByFile(fname)
		if fn != nil {
			if fn.Mtime != ftime {
				fn.Mtime = ftime
				fn.Ver++
				upload = true
			}
		} else {
			nfn := FileItemNode{fname, ftime, 1}
			v.appendFile(nfn)
			upload = true
		}
		if upload == true {
			fmt.Println("upload")
			uploads = append(uploads, f)
		}
	}
	v.Ver.Str = now()
	writeXML(v)

	fmt.Println(len(uploads))
	//uploadFiles(uploads)

	reader := bufio.NewReader(os.Stdin)
	input, _ := reader.ReadString('\n')
	fmt.Printf("Input Char Is : %v", string([]byte(input)[0]))
}

func now() string {
	return time.Now().Format("2006-01-02 15:04:05")
}
